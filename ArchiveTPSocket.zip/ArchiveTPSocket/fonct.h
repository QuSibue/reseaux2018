#include<stdio.h>
#include<stdlib.h>


int get_mot(const char* name,char *mot);
